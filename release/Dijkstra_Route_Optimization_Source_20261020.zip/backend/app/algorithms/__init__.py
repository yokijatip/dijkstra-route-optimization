"""Shortest path algorithm implementations."""
